jQuery(document).ready(function(){

    allSalesCurrent = [];
    $.getJSON( "https://api.myjson.com/bins/5bdb3", function( data ) {
        var items = '';
        var salesGraph = [];
        var headStart = '<div class="col-md-3">';
        headStart += '<div class="card" style="width: 27rem;">';
        headStart += '<div class="card-block">';
        headStart += '<h4 class="card-title pull-left">';
        var headEnd = '</h4>';
        headEnd += '<a href="" class="pull-right edit-card">';
        headEnd += '<img src="img/edit.png" width="20px;">';
        headEnd += '</a><h5>Sales By Month</h5>';
        var cardText = '</div>';
        cardText += '</div></div>';   
        var otherGraphs = '<table class="table table-fit "><thead><td>All Programs</td><td>Monthly Sales</td><td>Monthly Attendance</td></thead><tbody>';             
        var more = '<div class="more-description"><a onclick="show_more_description(this);" href="javascript:void(0);">More</a></div>';
        $.each( data, function( key, val ) {    
            if(key >= 3){
                otherGraphs += '<tr><td><b>'+val.Name+' <b></br><a class="more-graph">more</a></td><td>'+val.TotalMonthlySales+'</td><td>'+val.MonthlyAttendance+'</td></tr>';
            }
            else{
                var moreDiv = '<div class="more-graph-data" id="line-graph-'+key+'"></div>';
                var totalSales = '<div class="total-sales"><table class="table"><tr><td>Total Monthly Sales</td><td>Current $'+val.TotalMonthlySales+'</td><td >1 - Year<span id="total-sales-'+key+'"></span></td></tr></table></div>';
                allSalesCurrent[val.ProgramID] = val.Sales.CurrentYear;
                $.each( val.Sales.CurrentYear, function( index, value ) {
                    var month = getYear(index);
                    salesGraph[index] = {year:month,CurrentYear:val.Sales.CurrentYear[index], PreviousYear : val.Sales.PreviousYear[index]};
                });
                var graphID = "#total-sales-"+key;
                // create graph
                items = headStart+val.Name+headEnd+'<div class="card-text" id="graph-'+key+'"></div>'+totalSales+more+moreDiv+cardText;
                $( "#report-data").append( items );
                createGraph(salesGraph,key);
                createLineGraph(graphID,val.TotalMonthlySales,val.ProgramID, 1);

            }
        });

        otherGraphs += '</tbody></table>';
        jQuery("#other-graphs").append(otherGraphs);
    });

    // create line graph
    $.getJSON( "https://api.myjson.com/bins/47axv", function( data ) {
        var items = '';
        var graphTable = '<table class="table"><thead><tr><th>Price Name</th><th>Current</th><th>1 - year</th></tr></thead><tbody>'; 
        var previousProgramId = null;
        var tableData = '';
        var countGraphs = 0;
        var salesArray = [];
        var cnt = 0;
        var less = '<div class="more-description"><a onclick="show_less_description(this);" href="javascript:void(0);">Less</a></div>';
        $.each( data, function( key, val ) {
            if(countGraphs < 3) {
                if(previousProgramId !== null && val.ProgramID !== previousProgramId){
                    var table = graphTable+tableData+'</tbody></table>'+less;
                    jQuery("#line-graph-"+countGraphs).html(table);
                    graphID = "#sparkline-"+countGraphs;                
                    createLineGraph(graphID,salesArray,previousProgramId, 0,cnt);                
                    tableData = '';
                    salesArray = [];
                    cnt = 0;
                    countGraphs++;
                }
                salesArray.push(val.Sales);
                tableData += '<tr><td>'+val.Name+'</td><td> $'+val.Sales+'</td><td id="sparkline-'+countGraphs+'-'+cnt+'"></td></tr>';            
                previousProgramId = val.ProgramID;cnt
                cnt++;
            }
        });
    });

    
});

function show_more_description(this_sel){
    $(this_sel).parent().hide();
    $(this_sel).parent().next(".more-graph-data").show();    
}

function show_less_description(this_sel){
    $(this_sel).parent().parent().hide();
    $(this_sel).parent().parent().prev().show();    
}

function createGraph(salesGraph,index){
    var margin = {top: 10, right: 10, bottom: 10, left: 10},
    width = $("div.card").width();
    width = width - margin.left - margin.right,
    height = 150 - margin.top - margin.bottom;

    var x = d3.scale.ordinal()
    .rangeRoundBands([0, width], .1);

    var y0 = d3.scale.linear().domain([10000, 40000]).range([height, 0]);

    var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom");
    var svg = d3.select("#graph-"+index).append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("class", "graph")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    x.domain(salesGraph.map(function(d) { return d.year; }));
    y0.domain([0, d3.max(salesGraph, function(d) { return d.CurrentYear; })]);

    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);
      
    bars = svg.selectAll(".bar").data(salesGraph).enter();

    bars.append("rect")
      .attr("class", "bar2")
      .attr("x", function(d) { return x(d.year) + x.rangeBand()/2; })
      .attr("width", x.rangeBand() / 2)
      .attr("y", function(d) { return y0(d.PreviousYear); })
      .attr("height", function(d,i,j) { return height - y0(d.PreviousYear); }); 

    bars.append("rect")
      .attr("class", "bar1")
      .attr("x", function(d) { return x(d.year); })
      .attr("width", x.rangeBand()/2)
      .attr("y", function(d) { return y0(d.CurrentYear); })
      .attr("height"
      , function(d,i,j) { return height - y0(d.CurrentYear); }); 
}

function createLineGraph(chartId,current, programID,mainspark,cnt){
    lineColor = '#ECE9E6';
    lineWidth = 1;
    if (mainspark) {
        lineColor = '#999999';
        lineWidth = 2;
    }
    var arrayVal = [];
    options = {
        type: 'line',
        width: '70',
        height: '15',
        lineColor: lineColor,
        fillColor: 'transparent',
        lineWidth: lineWidth,
        spotColor: 'transparent',
        minSpotColor: '#e94345',
        maxSpotColor: '#02c902',
        highlightSpotColor: '',
        highlightLineColor: '',
        spotRadius: 2};
    if(typeof current == 'object'){
        $.each(current,function(index,value){
            arrayVal = allSalesCurrent[programID].slice();
            arrayVal.push(value);
            $(chartId+"-"+index).sparkline(arrayVal, options);
        });
    }
    else{
        
        arrayVal = allSalesCurrent[programID].slice();
        arrayVal.push(current);
        $(chartId).sparkline(arrayVal, options);
    }     
}

function type(d) {
    d.CurrentYear = +d.CurrentYear;
    return d;
}

function getYear(year){
    switch(year)
    {
        case 0:
        year = "Jan";
        break;

        case 1:
        year = "Feb";
        break;

        case 2:
        year = "Mar";
        break;

        case 3:
        year = "Apr";
        break;

        case 4:
        year = "May";
        break;

        case 5:
        year = "Jun";
        break;

        case 6:
        year = "Jul";
        break;

        case 7:
        year = "Aug";
        break;

        case 8:
        year = "Sep";
        break;

        case 9:
        year = "Oct";
        break;

        case 10:
        year = "Nov";
        break;

        case 11:
        year = "Dec";
        break;

        Default:
        year = "false"
        break;
    }
    return year;
}